/*******************************************************************************
  PHYS3071 (and PHYS7073) Lecture Week 7 Baumgardt 0123456
 
  Program friedman (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.
 
  About: This program solves the Kepler equation with the bisection and Newton methods 
 
  Compile: gcc -Wall -lm as07_kepler1.c -o as07_kepler1 
 
  Input: The eccentricity of the orbit and an accuracy parameter Delta 
         
 
  Output: t, M, E, x, y and r for two orbits 
***********************80*character*limit*good*for* a2ps***********************/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#define PI 3.1415927

int iter;

double newton(double m, double eps, double delta) {
 double eold,enew;
 double mbar;

 mbar=m-PI*floor(m/PI);                 // Reduce problem to root finding between 0 and PI

 enew=mbar/(1.0-eps);                   // First guess for E
 if (enew>1.0) enew=pow(mbar,1.0/3.0);  // Refine guess if E is larger than 1
 enew += PI*floor(m/PI);                // Correct for reduced range

 iter=0;
 do {
   eold = enew;
   enew = eold-(m-eold+eps*sin(eold))/(-1.0+eps*cos(eold));
   iter++;

   if (iter>20 || fabs(enew)>1E10) {
     printf("No convergence found !\n");
     exit(-1);
   }
 } while (fabs(eold-enew)>delta);

 return enew;
}

double bisection(double m, double eps, double delta) {
  double a,b;
  double fa,fb;
  double emed,fmed;

  iter=0;

  a  = -0.5;
  fa = m-a+eps*sin(a);
  b  = 4.5*PI;
  fb = m-b+eps*sin(b);

  if (fa*fb>0.0) {
    printf("Error - Root not bracketed\n");
    exit(-1);
  }

 do {
   emed = (a+b)/2.0; 
   fmed = m-emed+eps*sin(emed);
   if (fa*fmed>0.0) 
     a = emed;
   else
     b = emed;
   iter++;

   if (iter>100) {
     printf("No convergence found !\n");
     exit(-1);
   }
 } while (fabs(a-b)>delta);

 return (a+b)/2.0;
}

int main() {
 double m,e,eps,delta;
 double x,y,r;
 int i,method;
 FILE *dat;

 printf("This program solves the Kepler equation for orbits of different eccentriciy\n");

 printf("\nEnter the orbital eccentricity: "); 
 scanf("%lf",&eps);

 if (eps<0.0 || eps>=1.0) {
   printf("Error - Only 0<=eps<1 is allowed !\n");
   exit(-1);
 }

 printf("\nEnter the accuracy parameter Delta: ");
 scanf("%lf",&delta);

 printf("\nEnter 1 for bisection and 2 for Newton-Raphson: ");
 scanf("%i",&method);

 dat=fopen("kepler.dat","w");

 for (i=0;i<500;i++) {
   m = 4.0*PI*i/500.0;
   if (method==1)
      e = bisection(m, eps, delta);
   else
      e = newton(m, eps, delta);
 
   x = cos(e);
   y = sqrt(1.0-eps*eps)*sin(e);
   r = sqrt((x-eps)*(x-eps)+y*y);

   fprintf(dat,"%10.5lf %10.5lf %10.5lf %10.5lf %10.5lf %10.5lf %3i\n",m/(2.0*PI),m,e,x,y,r,iter); 
 }
 fclose(dat);

 exit(0);
}
